let img; // Declare variable 'img'.
let img2;
let img3;
let img4;
let img5;

var locations;

function setup() {
  createCanvas(2048/2, 2732/2);
  img = loadImage('CPMap.png'); // Load the image
  img2 = loadImage('MapPin.png');
  img3 = loadImage('Creede.png');
  img4 = loadImage('ACTB.png');
  img5 = loadImage('Artboard 1.png');
  img6 = loadImage('Artboard 2.png');
  img7 = loadImage('Artboard 3.png');
  img8 = loadImage('Artboard 4.png');
  img9 = loadImage('Artboard 5.png');
  img10 = loadImage('Artboard 6.png');
  img11 = loadImage('Artboard 7.png');
  img12 = loadImage('Artboard 8.png');
  img13 = loadImage('Artboard 9.png');
  img14 = loadImage('Artboard 10.png');
  img15 = loadImage('Artboard 11.png');
  
  locations =   [{x:  219.474, y: 2312.272, image: img5, toggle: false},
                 {x:  318.474, y: 2478.272, image: img6, toggle: false},
                 {x:  675.474, y: 2415.272, image: img7, toggle: false},
                 {x: 1036.474, y: 2236.272, image: img8, toggle: false},
                 {x: 1412.474, y: 2145.272, image: img9, toggle: false},
                 {x: 1668.474, y: 1947.272, image: img10, toggle: false},
                 {x: 1661.474, y: 1667.272, image: img11, toggle: false},
                 {x: 1532.474, y: 1581.272, image: img12, toggle: false},
                 {x: 1661.474, y: 1379.272, image: img13, toggle: false},
                 {x: 1644.474, y: 1076.272, image: img14, toggle: false},
                 {x: 1432.474, y: 156-.272, image: img15, toggle: false}];
  // alert('setup')
}



function draw() {
  scale(0.5)
  //Background Map
  image(img, 0, 0);
  image(img3, 41.05, 2632);
  image(img4, 66, 85);
  //Location pins
  //image(img2, 319.474, 2371.272);
  for(let i = 0; i < locations.length; i ++){
    image(img2, locations[i].x, locations[i].y);
    if(locations[i].toggle == true){
      image(locations[i].image,164, 1132);
    }
  }
  
}

function mousePressed() {
  print(mouseX);
   for(let i = 0; i < locations.length; i ++){
    locations[i].toggle = false;
    if(mouseX>locations[i].x/2-50 && mouseX<locations[i].x/2+50){
      print("true");
      if(mouseY>locations[i].y/2-50 && mouseY<locations[i].y/2+50){
        locations[i].toggle = true;
      }
    }
  }

}